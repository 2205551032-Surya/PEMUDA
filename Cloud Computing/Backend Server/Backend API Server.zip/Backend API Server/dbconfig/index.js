const Sequelize = require('sequelize');
const sequelize = new Sequelize('pemuda', 'root', 'pemuda-app123', {
    host:'34.128.92.53', 
    port:3306,
    dialect:'mysql'
});

sequelize.authenticate().then(() => {
    console.log("Connected to database!");
}).catch(() =>{
    console.log("Could not connect!");
})

module.exports = sequelize;