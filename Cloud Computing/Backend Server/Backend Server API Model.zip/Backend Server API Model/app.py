import mysql.connector
from mysql.connector import Error
from flask import Flask, request, jsonify
import tensorflow as tf
from tensorflow.keras.preprocessing.text import tokenizer_from_json
import numpy as np

# Konfigurasi database
db_config = {
    'host': '34.128.92.53',
    'user': 'root',
    'password': 'pemuda-app123',
    'database': 'pemuda'
}

# Membuat koneksi database
def get_db_connection():
    try:
        return mysql.connector.connect(**db_config)
    except Error as err:
        print(f"Database connection failed: {err}")
        raise

# Memastikan koneksi database berfungsi
try:
    connection = get_db_connection()
    if connection.is_connected():
        print("Connected to database!")
        connection.close()
except Error as err:
    print("Could not connect! Error:", err)

app = Flask(__name__)

# Memuat model yang telah dilatih
model = tf.keras.models.load_model('tf_model.h5')

def load_tokenizer(tokenizer_filename):
    with open(tokenizer_filename, 'r') as f:
        tokenizer_json = f.read()
    return tokenizer_from_json(tokenizer_json)

# Memuat tokenizer untuk skill dan regency
tokenizer_skill = load_tokenizer('tokenizer_skill.json')
tokenizer_regency = load_tokenizer('tokenizer_regency.json')

def preprocess_input(skill_input, regency_input):
    # Mengubah input teks menjadi urutan numerik
    skill_seq = tokenizer_skill.texts_to_sequences([skill_input])
    regency_seq = tokenizer_regency.texts_to_sequences([regency_input])
    
    # Melakukan padding pada urutan agar memiliki panjang yang sama
    skill_pad = tf.keras.preprocessing.sequence.pad_sequences(skill_seq, padding='post')
    regency_pad = tf.keras.preprocessing.sequence.pad_sequences(regency_seq, padding='post')
    
    return skill_pad, regency_pad

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Mendapatkan data JSON dari permintaan
        data = request.get_json()
        skill_input = data['skill_input']
        regency_input = data['regency_input']
        
        # Memproses input
        skill_pad, regency_pad = preprocess_input(skill_input, regency_input)
        
        # Membuat prediksi menggunakan model
        prediction = model.predict([skill_pad, regency_pad])
        
        # Memeriksa apakah ada rekomendasi (nilai prediksi bukan nol)
        has_recommendation = int(np.any(prediction))
        
        return jsonify({'recommendation': has_recommendation})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True)
