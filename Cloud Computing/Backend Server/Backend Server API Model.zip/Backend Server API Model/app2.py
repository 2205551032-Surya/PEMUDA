import mysql.connector
from mysql.connector import Error
from flask import Flask, request, jsonify
import tensorflow as tf
import numpy as np

# Konfigurasi database
db_config = {
    'host': '34.128.92.53',
    'user': 'root',
    'password': 'pemuda-app123',
    'database': 'pemuda'
}

# Membuat koneksi database
def get_db_connection():
    try:
        return mysql.connector.connect(**db_config)
    except Error as err:
        print(f"Database connection failed: {err}")
        raise

# Memastikan koneksi database berfungsi
try:
    connection = get_db_connection()
    if connection.is_connected():
        print("Connected to database!")
        connection.close()
except Error as err:
    print("Could not connect! Error:", err)

app = Flask(__name__)

# Memuat model yang telah dilatih
model = tf.keras.models.load_model('tf_model.h5')

def check_skill_and_regency(skill_input, regency_input):
    try:
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)

        # Query untuk memeriksa apakah skill cocok dan berada di regency yang dimaksud
        skill_query = f"""
        SELECT id_job_offer, req_skill FROM t_job_offer
        WHERE req_skill LIKE %s
        AND id_regency = (SELECT id_regency FROM t_regency WHERE TRIM(LOWER(regency_name)) = TRIM(LOWER(%s)))
        """

        # Parameter untuk query
        params = (f"%{skill_input.strip()}%", regency_input)
        cursor.execute(skill_query, params)
        result = cursor.fetchall()

        cursor.close()
        connection.close()

        # Jika ada data yang cocok
        if result:
            return {'recommendation': 1, 'matched_skills': [row['req_skill'] for row in result]}
        return {'recommendation': 0}
    except Error as err:
        print(f"Database query failed: {err}")
        return {'recommendation': 0}

def preprocess_input(skill_input, regency_input):
    # Menggabungkan input menjadi array numerik untuk model
    input_data = np.array([[len(skill_input), len(regency_input)]])
    return input_data

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Mendapatkan data JSON dari permintaan
        data = request.get_json()
        skill_input = data.get('skill_input')
        regency_input = data.get('regency_input')

        # Validasi input
        if not skill_input or not regency_input:
            return jsonify({'recommendation': 0, 'message': 'Skill or regency input is missing or empty'}), 400

        # Periksa data di database
        db_check = check_skill_and_regency(skill_input, regency_input)

        if db_check['recommendation'] == 0:
            return jsonify({'recommendation': 0, 'message': 'No match found in the database'}), 200

        # Memproses input untuk model
        model_input = preprocess_input(skill_input, regency_input)
        prediction = model.predict(model_input)

        # Interpretasi hasil prediksi model
        has_recommendation = int(np.any(prediction > 0.5))

        return jsonify({'recommendation': has_recommendation, 'matched_skills': db_check.get('matched_skills', [])})
    except Exception as e:
        return jsonify({'error': str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True)
